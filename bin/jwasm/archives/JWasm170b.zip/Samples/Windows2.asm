
;--- Win32 "hello world" console application in MASM syntax.
;--- The MASM32 include files are used.
;--- assemble: JWasm WINDOWS2.ASM
;--- link:     WLINK system nt file WINDOWS2.OBJ

	.386
	.MODEL FLAT, stdcall
	option casemap:none

	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc

	.CONST

szString    db 13,10,"hello, world.",13,10
LSTRING		equ $ - szString

        .CODE

main    proc

local   dwWritten:dword
local   hConsole:dword

        invoke  GetStdHandle, STD_OUTPUT_HANDLE
        mov     hConsole,eax

        invoke  WriteConsoleA, hConsole, addr szString, LSTRING, addr dwWritten, 0

        xor     eax,eax
        ret
main    endp

;--- entry

mainCRTStartup  proc c

        invoke  main
        invoke  ExitProcess, eax

mainCRTStartup endp

        END mainCRTStartup

