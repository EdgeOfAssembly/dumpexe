
;--- this is a very simple hello world app for Linux.
;--- assemble: JWasm Linux1.asm
;--- link:     WLINK format ELF runtime linux file Linux1.obj name Linux1.

    .386
    .model flat

stdout    equ 1
SYS_EXIT  equ 1
SYS_WRITE equ 4

    .data

string  db 10,"Hello, world!",10

    .code

main proc c

    mov ecx, offset string
    mov edx, sizeof string
    mov ebx, stdout
    mov eax, SYS_WRITE
    int 80h
    mov eax, SYS_EXIT
    int 80h
main endp

    end main

