
;--- this is a very simple hello world app.
;--- assemble: JWasm Dos1.asm
;--- link:     WLINK system DOS com file Dos1.obj

    .286
    .model tiny

	.data
    
str1    db 13,10,"Hello, world!",13,10,'$'

	.code

	org 100h

main proc c

    mov ah, 09h
    mov dx, offset str1
    int 21h
    mov ax, 4c00h
    int 21h

    ret
main endp

    end main

